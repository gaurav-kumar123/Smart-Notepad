import NotePadFileModel
import speech_recognition as s
class File_Controller:
    def __init__(self):
        self.file_model=NotePadFileModel.File_Model()
    
    def save_file(self,msg):
        self.file_model.save_file(msg)
    
    def save_as(self,msg):
        self.file_model.save_as(msg)

    def read_file(self,url=''):
        self.msg,self.base=self.file_model.read_file(url)
        return self.msg,self.base
    
    def new_file(self):
        self.file_model.new_file()


    
    def take_query(self):
        sr=s.Recognizer() #recorder and converter into text
        print("Say Something:")
        with s.Microphone() as m:#from this not do exit function and enter function
                
                audio=sr.listen(m)#wait time out error can give
                
                text=sr.recognize_google(audio,language='en-IN')#request error can give  
                print(text)
                return text
        
                



