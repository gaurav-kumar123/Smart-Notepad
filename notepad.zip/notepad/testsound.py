import speech_recognition as s
def take_query():
    sr=s.Recognizer() #recorder and converter into text
    print("Say Something:")
    with s.Microphone() as m:#from this not do exit function and enter function
        try:
            audio=sr.listen(m)#wait time out error can give
            text=sr.recognize_google(audio,language='en-IN')#request error can give  
            return text

        except:
            print("Exception occured")

print("you said",take_query())

# import tkinter
# import tkinter.ttk
# root=tkinter.Tk()
# root.geometry('400x300')
# mytext=tkinter.Text(root)
# mytext.config(wrap="word",relief=tkinter.FLAT)
# # mytext.pack(fill=tkinter.BOTH,expand=True)
# my_scrollbar=tkinter.ttk.Scrollbar(root)
# my_scrollbar.pack(side=tkinter.RIGHT,fill=tkinter.Y)
# mytext.pack(fill=tkinter.BOTH,expand=True)
# my_scrollbar.config(command=mytext.yview)

# mytext.config(yscrollcommand=my_scrollbar.set)
# root.mainloop()

